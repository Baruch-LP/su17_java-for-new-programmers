package baruchJNP.pitreL.project1;

public class Task2 {
	
	public static void task(){
		int a = 20;
		int b = 5;
		
		System.out.println(a*b);
	}

}
